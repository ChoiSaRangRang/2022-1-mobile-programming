<!doctype html>
<html lang="ko">
  <head>
    <meta charset="utf-8">
    <title>정보 입력</title>
    <style>
      body {
        font-family: Consolas, monospace;
        font-family: 15px;
      }
    </style>
  </head>

  <body>
  <h1>데이터 검색</h1>
    <form action="Json_insert_save.php" method="POST">
      <p><input type="text" size="80" name="Jsonname" placeholder='검색하고 싶은 이름을 Json타입으로 입력하시오(ex.{"name":"사랑"})' required></p>
      <button>검색</button>
    </from>
  </body>
  </html>