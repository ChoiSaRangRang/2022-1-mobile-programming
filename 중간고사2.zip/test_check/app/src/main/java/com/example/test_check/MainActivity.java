package com.example.test_check;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void watermelon(View view) {

    }

    public void image(View view) {
        Intent second = new Intent(MainActivity.this, imageActivity.class);
        startActivity(second);
    }

    public void clear(View view) {
        final CheckBox watermelon=(CheckBox) findViewById(R.id.watermelon);
        final CheckBox peach=(CheckBox) findViewById(R.id.peach);

        if(watermelon.isChecked()==true || peach.isChecked()==true){
            watermelon.setChecked(false);
            peach.setChecked(false);
        }
    }

    public void onclick(View view) {
        final CheckBox watermelon=(CheckBox) findViewById(R.id.watermelon);
        final CheckBox peach=(CheckBox) findViewById(R.id.peach);

        switch (view.getId()){
            case R.id.watermelonbutton:
                if(watermelon.isChecked()==false){
                    watermelon.setChecked(true);
                }
                else {
                    watermelon.setChecked(false);
                }
                break;
            case R.id.peachbutton:
                if(peach.isChecked()==false){
                    peach.setChecked(true);
                }
                else {
                    peach.setChecked(false);
                }
                break;
        }
    }
}