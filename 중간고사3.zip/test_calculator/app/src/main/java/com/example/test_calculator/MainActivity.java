package com.example.test_calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText num1, num2, sum;
    int a, b, c = 0;
    Button plus, minus, multi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void btnClick(View view) {
        Toast.makeText(getApplicationContext(), "안녕하세요", Toast.LENGTH_SHORT).show();
    }

    public void btnClick1(View view) {
        Toast.makeText(getApplicationContext(), "고맙습니다", Toast.LENGTH_LONG).show();
    }

    public void onclick(View view) {
        switch (view.getId()) {
            case R.id.plus:
                findViewById(R.id.plus).setSelected(true);
                findViewById(R.id.minus).setSelected(false);
                findViewById(R.id.multi).setSelected(false);
                break;
            case R.id.minus:
                findViewById(R.id.plus).setSelected(false);
                findViewById(R.id.minus).setSelected(true);
                findViewById(R.id.multi).setSelected(false);
                break;
            case R.id.multi:
                findViewById(R.id.plus).setSelected(false);
                findViewById(R.id.minus).setSelected(false);
                findViewById(R.id.multi).setSelected(true);
                break;
        }
    }

    public void result(View view) {
        num1 = (EditText) findViewById(R.id.num1);
        num2 = (EditText) findViewById(R.id.num2);
        sum = (EditText) findViewById(R.id.sum);
        a = Integer.parseInt((num1.getText().toString()));
        b = Integer.parseInt((num2.getText().toString()));
        plus = (Button) findViewById(R.id.plus);
        minus = (Button) findViewById(R.id.minus);
        multi = (Button) findViewById(R.id.multi);

        if(plus.isSelected()==true){
            c=a+b;
        }
        if(minus.isSelected()==true){
            c=a-b;
        }
        if(multi.isSelected()==true){
            c=a*b;
        }
        sum.setText(String.valueOf(c));
    }
}