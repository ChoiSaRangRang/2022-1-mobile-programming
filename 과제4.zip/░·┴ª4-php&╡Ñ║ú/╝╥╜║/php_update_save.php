<?php
  $edit_emp_ID = $_POST[ 'edit_emp_ID' ];
  $jb_conn = mysqli_connect( "sc1.swu.ac.kr", "fkd0802", "fkd0802945", "fkd0802_ts", "13306" );
  $jb_sql_edit = "SELECT * FROM info WHERE ID = '$edit_emp_ID';";
  $jb_result = mysqli_query( $jb_conn, $jb_sql_edit );
  $jb_row = mysqli_fetch_array( $jb_result );
?>

<!doctype html>
<html lang="ko">
  <head>
    <meta charset="utf-8">
    <title>데이터 변경</title>
    <style>
      body {
        font-family: Consolas, monospace;
        font-family: 15px;
      }
    </style>
  </head>
  <body>
    <h1>데이터 변경</h1>
    <form action="php_update_print.php" method="POST">
        <input type="hidden" name="ID" value="<?php echo $jb_row[ 'ID' ]; ?>">
      <p>닉네임 <input type="text" name="newuserID" value="<?php echo $jb_row[ 'userID' ]; ?>" required></p>
      <p>이름 <input type="text" name="newname" value="<?php echo $jb_row[ 'name' ]; ?>" required></p>
      <p>출생년도 <input type="text" name="newbirthYear" value="<?php echo $jb_row[ 'birthYear' ]; ?>" required></p>
      <p>주소 <input type="text" name="newaddr" value="<?php echo $jb_row[ 'addr' ]; ?>" required></p>
      <button>변경하기</button>
    </form>
  </body>
</html>