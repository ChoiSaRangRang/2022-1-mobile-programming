<!doctype html>
<html lang="ko">
  <head>
    <meta charset="utf-8">
    <title>데이터 출력</title>
    <style>
      body {
        font-family: Consolas, monospace;
        font-family: 15px;
      }
      table {
        width: 90%;
        margin:auto;
      }
      th, td {
        padding: 10px;
        border-bottom: 1px solid #dadada;
        text-align:center;
      }
    </style>
  </head>
  <body>
  <p>
      <a href="php_insert.php">데이터 입력 페이지</a>
      <a href="php_list.php">데이터 리스트 페이지</a>
      <a href="php_delete.php">데이터 삭제 페이지</a>
      <a href="php_update.php">데이터 변경 페이지</a>
     </p>
  <h1>데이터 리스트</h1>
    <table>
      <thead>
        <tr>
          <th>번호</th>
          <th>닉네임</th>
          <th>이름</th>
          <th>출생년도</th>
          <th>주소지</th>
          <th>입력 시간</th>
        </tr>
      </thead>
      <tbody>
        <?php
          $jb_conn = mysqli_connect( "sc1.swu.ac.kr", "fkd0802", "fkd0802945", "fkd0802_ts", "13306" );
          $jb_sql = "SELECT * FROM info;";
          $jb_result = mysqli_query( $jb_conn, $jb_sql );
          while( $jb_row = mysqli_fetch_array( $jb_result ) ) {
            echo '<tr><td>' . $jb_row[ 'ID' ] . '</td><td>' . $jb_row[ 'userID' ] . '</td><td>'. $jb_row[ 'name' ] . '</td><td>' . $jb_row[ 'birthYear' ] . '</td><td>' . $jb_row[ 'addr' ] . '</td><td>' . $jb_row[ 'rdate' ] . '</td></tr>';
          }
        ?>
      </tbody>
    </table>
  </body>
</html>