<!doctype html>
<html lang="ko">
  <head>
    <meta charset="utf-8">
    <title>정보 입력</title>
    <style>
      body {
        font-family: Consolas, monospace;
        font-family: 15px;
      }
    </style>
  </head>
  <body>
  <p>
      <a href="php_insert.php">데이터 입력 페이지</a>
      <a href="php_list.php">데이터 리스트 페이지</a>
      <a href="php_delete.php">데이터 삭제 페이지</a>
      <a href="php_update.php">데이터 변경 페이지</a>
     </p>
    <h1>데이터 입력</h1>
    <form action="php_insert_save.php" method="POST">
      <p><input type="text" size="50" name="userID" placeholder="사용할 닉네임을 영어대문자로 입력하시요(ex.JR)" required></p>
      <p><input type="text" size="50" name="name" placeholder="사용자의 이름을 입력하시오(ex.종현)" required></p>
      <p><input type="text" size="50" name="birthYear" placeholder="사용자의 출생년도를 입력하시오(ex.1995)" required></p>
      <p><input type="text" size="50" name="addr" placeholder="사용자의 주소지를 입력하시오(ex.강릉)" required></p>
      <button>정보 입력</button>
    </form>
  </body>
</html>