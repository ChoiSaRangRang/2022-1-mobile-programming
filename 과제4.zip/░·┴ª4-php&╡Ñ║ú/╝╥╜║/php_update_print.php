<!doctype html>
<html lang="ko">
  <head>
    <meta charset="utf-8">
    <title>데이터 변경</title>
    <style>
      body {
        font-family: Consolas, monospace;
        font-family: 15px;
      }
    </style>
  </head>
  <body>
  <p>
      <a href="php_insert.php">데이터 입력 페이지</a>
      <a href="php_list.php">데이터 리스트 페이지</a>
      <a href="php_delete.php">데이터 삭제 페이지</a>
      <a href="php_update.php">데이터 변경 페이지</a>
     </p>
    <?php
      $ID = $_POST[ 'ID' ];
      $userID = $_POST[ 'newuserID' ];
      $name = $_POST[ 'newname' ];
      $birthYear = $_POST[ 'newbirthYear' ];
      $addr = $_POST[ 'newaddr' ];
      if ( is_null( $name ) ) {
        echo '<h1>Fail!</h1>';
      } else {
        $jb_conn = mysqli_connect( "sc1.swu.ac.kr", "fkd0802", "fkd0802945", "fkd0802_ts", "13306" );
        $jb_sql = "UPDATE info SET name = '$name', userID = '$userID', birthYear = '$birthYear', addr = '$addr' where ID = $ID;";
        mysqli_query( $jb_conn, $jb_sql );
        echo '<h1>Success!</h1>';
      }
    ?>
  </body>
</html>