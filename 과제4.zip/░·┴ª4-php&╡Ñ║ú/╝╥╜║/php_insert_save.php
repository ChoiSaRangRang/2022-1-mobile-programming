<!doctype html>
<html lang="ko">
  <head>
    <meta charset="utf-8">
    <title>정보 입력 저장</title>
    <style>
      body {
        font-family: Consolas, monospace;
        font-family: 15px;
      }
    </style>
  </head>
  <body>
  <p>
      <a href="php_insert.php">데이터 입력 페이지</a>
      <a href="php_list.php">데이터 리스트 페이지</a>
      <a href="php_delete.php">데이터 삭제 페이지</a>
      <a href="php_update.php">데이터 변경 페이지</a>
     </p>
    <?php
      $userID = $_POST[ 'userID' ];
      $name = $_POST[ 'name' ];
      $birthYear = $_POST[ 'birthYear' ];
      $addr = $_POST[ 'addr' ];
      $curr_time=time();
      $rdate = date("Y-m-d H:i:s", $curr_time);

      if ( is_null( $userID ) ) {
        echo '<h1>Fail!</h1>';
      } else {
        $jb_conn = mysqli_connect( "sc1.swu.ac.kr", "fkd0802", "fkd0802945", "fkd0802_ts", "13306" );
        $jb_sql = "INSERT INTO info ( userID, name, birthYear, addr, rdate ) VALUES ( '$userID', '$name', '$birthYear', '$addr', '$rdate');";
        mysqli_query( $jb_conn, $jb_sql );
        echo '<h1>Success!</h1>';
      }
    ?>
  </body>
</html>